package juego;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class juegoInterno {
	private static Generador _random;

	public static void setGenerador(Generador generador) {
		_random = generador;

	}

	public juegoInterno() {
		_random = new GeneradorAleatorio();
	}

	public void llenarAlbum(Usuario us) {
		agregarAAlum(us, damePaquete());
	}

	public void llenarAlbumConDonacion(ArrayList<Usuario> usuarios, Usuario us) {
		agregarAABumConDonacion(usuarios, us, damePaquete());

	}
	
	public void llenarAlbumConDonacionManual(ArrayList<Usuario> usuarios, Usuario us, ArrayList<Figurita> paquete) {
		agregarAAlum(us, paquete);
		intercambiarFiguritas(usuarios, us);
	}


	public void agregarAAlum(Usuario us, ArrayList<Figurita> figuritas) {
		for (int i = 0; i < figuritas.size(); i++) {
			boolean flag = true;
			for (Figurita figurita : us.getAlbum()) {
				if (figurita.getNumeroFigurita() == figuritas.get(i).getNumeroFigurita()) {
					flag = false;
				}
			}

			if (flag) {
				us.getAlbum().add(figuritas.get(i));
			} else {
				us.getFiguritasRepetidas().add(figuritas.get(i));
			}

		}

	}

	public void agregarAABumConDonacion(ArrayList<Usuario> usuarios, Usuario us, ArrayList<Figurita> figuritas) {
		
		int contador = usuarios.size();
		for (int i = 0; i < figuritas.size(); i++) {
			boolean flag = true;
			boolean flag2 = false;
			for (Figurita figurita : us.getAlbum()) {
				if (figurita.getNumeroFigurita() == figuritas.get(i).getNumeroFigurita()) {
					flag = false;
				}
			}

			if (flag) {
				us.getAlbum().add(figuritas.get(i));
			} else {

				for (int j = 0; j < usuarios.size(); j++) {
					int iterador = 0;
					while (!flag2) {
						flag2 = tieneFigurita(usuarios.get(j), figuritas.get(i));
						if (flag2 == true) {
							us.usuarioDono();
						}
						iterador++;

						if (contador == iterador) {
							break;
						}
					}

				}

			}

		}
	}
	
	public void intercambiarFiguritas(ArrayList<Usuario> usuarios, Usuario us) {
		Integer cantidadIntercambiadas = 0;
		Iterator<Figurita> figuritaUserPrincipal = us.getFiguritasRepetidas().iterator();
		
		while (figuritaUserPrincipal.hasNext()) {
		boolean flag = false;
			Figurita figu1 = figuritaUserPrincipal.next();
			for (Usuario usuario : usuarios) {
				if (!figuritaRepetida(usuario, figu1) && usuario.getFiguritasRepetidas().size() > 0) {
					Iterator<Figurita> figuritaUserSecundario = usuario.getFiguritasRepetidas().iterator();
					while (figuritaUserSecundario.hasNext()) {
						Figurita figu2 = figuritaUserSecundario.next();
						if (!figuritaRepetida(us, figu2) && !flag) {
							// el usuario princiapl agrega la figurita
							us.getAlbum().add(figu2);
							// el 2do usuario agrega la figurita
							usuario.getAlbum().add(figu1);
					
							flag = true;
							// eliminamos ambas figuritas de los albumnes repetidos de cada uno
							figuritaUserSecundario.remove();
							figuritaUserPrincipal.remove();
							
							cantidadIntercambiadas++;
							
//							us.setCantidadDeFigusDonadas(us.getCantidadDeFigusDonadas() + cantidadIntercambiadas);
							us.usuarioDono();
							

//							System.out.println("Usuario 1: " +us.getFiguritasRepetidas().size());
//							System.out.println("Usuario 2: " +usuario.getFiguritasRepetidas().size());
							
						}
					}
				}
			}
			
		}
	}

	public boolean tieneFigurita(Usuario us, Figurita figu) {
		boolean flag = true;

		for (Figurita figurita : us.getAlbum()) {
			if (figurita.getNumeroFigurita() == figu.getNumeroFigurita()) {
				flag = false;
			}
		}
		if (flag) {
			us.getAlbum().add(figu);
//			System.out.println("done");
		}

		return flag;

	}
	
	//Este metodo devuelve un paquete de 5 figuritas 
	public ArrayList<Figurita> damePaquete() {

		ArrayList<Figurita> paquete = new ArrayList<Figurita>();

		for (int i = 0; i < 5; i++) {
			paquete.add(dameFigurita(dameRandom()));
		}
		return paquete;
	}
	
	
	// Este metodo da un numero random del 1 al 638
	public Integer dameRandom() {
		return _random.nextInt(638) ;
	}



	


	

	// inicia en falso, si tiene la figurita repetida, retorna true, sino falso
	public boolean figuritaRepetida(Usuario us, Figurita figuritaUserPrincipal) {
		boolean flag = false;

		for (Figurita figurita : us.getAlbum()) {
			if (figurita.getNumeroFigurita() == figuritaUserPrincipal.getNumeroFigurita()) {
				flag = true;
			}
		}
		return flag;
	}
	
	// Este metodo nos da la figurita dependiendo el numero que le pasemos
	public  Figurita dameFigurita(int i) {
		Figurita figurita = new Figurita(i);
		return figurita;
	}

	protected Usuario inicializarUsuario() {
		Album a = new Album(new HashSet<Figurita>());
		ArrayList<Figurita> figuritasRepetidas = new ArrayList<Figurita>();
		Usuario usuario = new Usuario(a, figuritasRepetidas);
		return usuario;
	}

}
