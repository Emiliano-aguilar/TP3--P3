package juego;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;

public class Inicio extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Inicio frame = new Inicio();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	/**
	 * Create the frame.
	 */
	public Inicio() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 520, 396);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(139, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		JButton btnNewButton = new JButton();
		btnNewButton.setText("SOLITARIO");
		btnNewButton.setBounds(120, 120, 280, 50);
		btnNewButton.setIcon(new ImageIcon(Inicio.class.getResource("/Image/fondoboton.png")));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Solitario newframe = new Solitario();
				newframe.setVisible(true);
				dispose();
			}
		});
		contentPane.setLayout(null);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Intercambio con donaciones");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				conDonaciones newframe2 = new conDonaciones();
				newframe2.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(Inicio.class.getResource("/Image/FONDOBOTON2.png")));
		btnNewButton_1.setBounds(120, 184, 280, 50);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Intercambio equivalente");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				conIntercambios newframe3 = new conIntercambios();
				newframe3.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setIcon(new ImageIcon(Inicio.class.getResource("/Image/fondobonton3.png")));
		btnNewButton_2.setBounds(120, 248, 280, 50);
		contentPane.add(btnNewButton_2);
		
		JLabel lblNewLabel = new JLabel("ALBUM DE FIGURITAS FIFA WORLD CUP QATAR 2022");
		lblNewLabel.setForeground(new Color(255, 255, 240));
		lblNewLabel.setBounds(20, 0, 481, 72);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 18));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Selecciona de que modo quieres completar el album");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(63, 59, 539, 21);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 18));
		contentPane.add(lblNewLabel_1);
		
	}
}
