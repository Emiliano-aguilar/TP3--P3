package juego;

import java.util.Random;

public class GeneradorAleatorio implements Generador {

	private Random _random;
	
	public GeneradorAleatorio() {
		_random = new Random();
	}
	
	

	@Override
	public int nextInt(int rango) {
		// TODO Auto-generated method stub
		return _random.nextInt(rango);
	}

}
