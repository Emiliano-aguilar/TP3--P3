package juego;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashSet;

import org.junit.Before;
import org.junit.Test;

public class juegoInternoTest {

	

	
	@Test
	public void dameFiguritaTest() {
		Figurita figu = crearFugurita(423);
		assertEquals(figu.getNumeroFigurita(), 423);
	}

	@Test 
	public void figuritaRepetidaTest() {
		juegoInterno nuevo = new juegoInterno();
		Usuario us = nuevo.inicializarUsuario();
		us.getAlbum().add(crearFugurita(342));
		Figurita figu = crearFugurita(342);
		assertTrue(nuevo.figuritaRepetida(us, figu));
	}
	
	@Test
	public void tieneFiguritaTest() {
		juegoInterno nuevo = new juegoInterno();
		Usuario us = nuevo.inicializarUsuario();
		us.getAlbum().add(crearFugurita(342));
		Figurita figu = crearFugurita(342);
		assertFalse(nuevo.tieneFigurita(us, figu));
	}
	
	
	@Test
	public void damePaqueteTest() {
		juegoInterno nuevo = new juegoInterno();
		assertEquals(5, nuevo.damePaquete().size());
	}
	
	@Test 
	public void agregarAAlbumTest() {
		juegoInterno nuevo = new juegoInterno();
		Usuario us = nuevo.inicializarUsuario();
		ArrayList<Figurita> paquete = inicializarPaqueteSinRepetidas();
		nuevo.agregarAAlum(us, paquete);
		assertEquals(5, us.getAlbum().size());
	}
	
	public void agregarAAlbumConRepetidaTest() {
		juegoInterno nuevo = new juegoInterno();
		Usuario us = nuevo.inicializarUsuario();
		ArrayList<Figurita> paquete = inicializarPaqueteConRepetidas();
		nuevo.agregarAAlum(us, paquete);
		assertEquals(4, us.getAlbum().size());
	}
	
	@Test
	public void agregarAlbumConDonacionesTest() {
		juegoInterno nuevo = new juegoInterno();
		Usuario us = nuevo.inicializarUsuario();
		ArrayList<Usuario> usuarios = inicializarArregloDeUsuarios();
		ArrayList<Figurita> paquete = inicializarPaqueteConRepetidas();
		nuevo.agregarAABumConDonacion(usuarios, us, paquete);
		assertEquals(4, us.getAlbum().size());
	}
	
	

	@Test
	public void agregarAlbumConIntercambiosTest() {
		juegoInterno nuevo = new juegoInterno();
		Usuario us = nuevo.inicializarUsuario();
		ArrayList<Usuario> usuarios = inicializarArregloDeUsuarios();
		ArrayList<Figurita> paquete = inicializarPaqueteConRepetidas();
		nuevo.llenarAlbumConDonacionManual(usuarios, us ,paquete);
		assertEquals(4, us.getAlbum().size());
	}
	
	private ArrayList<Usuario>  inicializarArregloDeUsuarios() {
		ArrayList<Usuario> usuarios =  new ArrayList<Usuario>();
		juegoInterno nuevo = new juegoInterno();
		Usuario us1 = nuevo.inicializarUsuario();
		Usuario us2 = nuevo.inicializarUsuario();
		Usuario us3 = nuevo.inicializarUsuario();
		
		usuarios.add(us1);
		usuarios.add(us2);
		usuarios.add(us3);
		
		return usuarios;
	}
	private ArrayList<Figurita> inicializarPaqueteSinRepetidas() {
		ArrayList<Figurita> paqueteAux = new ArrayList<Figurita>();
		paqueteAux.add(crearFugurita(296));
		paqueteAux.add(crearFugurita(285));
		paqueteAux.add(crearFugurita(225));	
		paqueteAux.add(crearFugurita(275));
		paqueteAux.add(crearFugurita(264));
		return paqueteAux;
	}
	
	private ArrayList<Figurita> inicializarPaqueteConRepetidas() {
		ArrayList<Figurita> paqueteAux = new ArrayList<Figurita>();
		paqueteAux.add(crearFugurita(296));
		paqueteAux.add(crearFugurita(285));
		paqueteAux.add(crearFugurita(296));
		paqueteAux.add(crearFugurita(275));
		paqueteAux.add(crearFugurita(184));
		return paqueteAux;
	}

	private Figurita crearFugurita(Integer i) {
		juegoInterno nuevo = new juegoInterno();
		juegoInterno.setGenerador(new GeneradorPrefijado(i));
		Figurita figu = nuevo.dameFigurita(nuevo.dameRandom());
		return figu;
	}
	
	
}
