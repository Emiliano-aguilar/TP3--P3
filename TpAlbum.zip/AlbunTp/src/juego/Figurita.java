package juego;

public class Figurita {
	private int numeroFigurita;
	
	private static Generador _random;

	public static void setGenerador(Generador generador) {
		_random = generador; 
	}

//	public static Figurita aleatorio(Integer i) {
//		Figurita ret = new Figurita(i);
//
//		
//		ret.set(i, _random.nextBoolean());
//		ret.
//		return ret;
//		
//		
//	}
	
	
	
	

	public Figurita(int numeroFigurita) {
		this.numeroFigurita = numeroFigurita;
	}







	public int getNumeroFigurita() {
		return numeroFigurita;
	}
	
	
	
	
	
	

}
