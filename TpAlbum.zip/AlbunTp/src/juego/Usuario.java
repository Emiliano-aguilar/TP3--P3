package juego;

import java.util.ArrayList;
import java.util.HashSet;

public class Usuario {
	private Album album;
	private ArrayList<Figurita> figuritasRepetidas;
	private int cantidadDeFigusDonadasOIntercambiadas;

	public Usuario(Album album, ArrayList<Figurita> figuritasRepetidas) {
		this.album = album;
		this.figuritasRepetidas = figuritasRepetidas;
		this.cantidadDeFigusDonadasOIntercambiadas = 0;
	}

	public HashSet<Figurita> getAlbum() {
		return album.getAlbum();

	}

	public int getCantidadDeFigusDonadasOIntercambiadas() {
		return cantidadDeFigusDonadasOIntercambiadas;
	}

	public ArrayList<Figurita> getFiguritasRepetidas() {
		return figuritasRepetidas;
	}

	public void usuarioDono() {
		this.cantidadDeFigusDonadasOIntercambiadas++;
	}

	public boolean albumCompleto() {
		if (album.getAlbum().size() == 638) {
			return true;
		}
		return false;
	}

}
 